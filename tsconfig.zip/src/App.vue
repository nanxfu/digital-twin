<script setup lang="ts">
import ThreeScene from "./components/ThreeScene/ThreeScene.vue";
import MachineState from "./components/MachineState/MachineState.vue";
import {onMounted} from "vue";

onMounted(() => {
  document.body.setAttribute('arco-theme', 'dark')
})
</script>

<template>

    <aside class="sidebar">
      <a-scrollbar style="height:100vh;overflow-y: scroll;">
      <a-typography>
        <a-typography-title :heading="4" style="text-align: center">
          施肥机数字前端设计
        </a-typography-title>
        <a-divider/>
      </a-typography>
      <div style="display: flex;flex: 1;justify-content: space-evenly">
        <a-button>设备A</a-button>
        <a-button>设备B</a-button>
        <a-button>设备C</a-button>
      </div>
      <machine-state/>
      </a-scrollbar>
    </aside>


  <div class="container">
    <three-scene/>
  </div>
</template>

<style>
.container {
  height: 100vh;
}

aside {
  position: fixed;
  width: 30%;
  top: 0;
  bottom: 0;
  background-color: #100c2a;
}

html, body {
  overflow: hidden;
}

</style>
