<template>
  <div class="wrapper">
    <div class="chart" ref="chartRef"></div>
    <a-typography>
      <a-typography-title :heading="5">
        日志
      </a-typography-title>
      <a-divider/>
    </a-typography>
    <a-timeline>
      <a-timeline-item label="2017-03-10" dotColor="#00B42A">
        The first milestone
      </a-timeline-item>
      <a-timeline-item label="2018-05-22">The second milestone</a-timeline-item>
      <a-timeline-item label="2020-06-22" dotColor="#F53F3F">
        The third milestone
        <IconExclamationCircleFill
            :style="{ color: 'F53F3F', fontSize: '12px', marginLeft: '4px' }"
        />
      </a-timeline-item>
      <a-timeline-item label="2020-09-30" dotColor="#C9CDD4">
        The fourth milestone
      </a-timeline-item>
    </a-timeline>
  </div>

</template>

<script setup lang="ts">
import {onMounted, ref} from "vue";
import * as echarts from 'echarts';
import {SVGRenderer} from 'echarts/renderers';

let chartRef = ref<HTMLElement | null>(null)

onMounted(() => {

  const chart = echarts.init(chartRef.value, 'dark')

  chart.setOption({
    title: {
      text: '肥液参数'
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    legend: {
      data: ['ec', 'pH']
    },
    toolbox: {
      feature: {
        saveAsImage: {}
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      }
    ],
    yAxis: [
      {
        type: 'value'
      }
    ],
    series: [
      {
        name: 'ec',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series'
        },
        data: [120, 132, 101, 134, 90, 230, 210]
      },
      {
        name: 'pH',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series'
        },
        data: [220, 182, 191, 234, 290, 330, 310]
      }
    ]
  })
})
</script>

<style scoped>
.chart {
  height: 300px;
}
.wrapper{
  padding: 10px 5px;
}
</style>